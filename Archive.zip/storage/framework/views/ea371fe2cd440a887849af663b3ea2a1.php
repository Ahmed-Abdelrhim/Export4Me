<header class="bmd-layout-header ">
    <div class="navbar navbar-light bg-faded animate__animated animate__fadeInDown">
        <button class="navbar-toggler animate__animated animate__wobble animate__delay-2s" type="button"
                data-bs-toggle="collapse" data-bs-target="#dw-s1">
            <span class="navbar-toggler-icon"></span>
            <!-- <i class="material-Animation">menu</i> -->
        </button>
        <ul class="nav navbar-nav ">
            

            
            
            
            
            


            <?php
                $currentRoute = Route::currentRouteName();
            ?>

            <li class="nav-item">
                <?php if(isset(auth('web')->user()->profile_img)): ?>

                    <?php if(isset($currentRoute) and !empty($currentRoute)): ?>
                        <?php if($currentRoute == 'admin.dashboard'): ?>
                            <img class="rounded-circle screen-user-profile"
                                 src="<?php echo e(asset('images/' . auth('web')->user()->profile_img )); ?>" alt="logo">
                        <?php endif; ?>


                        <?php if($currentRoute != 'admin.dashboard'): ?>
                            <a href="<?php echo e(route('admin.dashboard')); ?>">
                                <img class="rounded-circle screen-user-profile"
                                     src="<?php echo e(asset('images/' . auth('web')->user()->profile_img )); ?>" alt="logo">
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>

                <?php else: ?>

                    <?php if($currentRoute == 'admin.dashboard'): ?>
                        <img class="rounded-circle screen-user-profile"
                             src="<?php echo e(asset('assets/img/zexport4me-logo.png')); ?>" alt="logo">
                    <?php endif; ?>

                    <?php if($currentRoute != 'admin.dashboard'): ?>
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <img class="rounded-circle screen-user-profile"
                                 src="<?php echo e(asset('assets/img/zexport4me-logo.png')); ?>" alt="logo">
                        </a>
                    <?php endif; ?>

                <?php endif; ?>


            </li>
            <li class="nav-item">
                <div class="dropdown">
                    <button class="btn  dropdown-toggle m-0" type="button" id="dropdownMenu4" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                        <?php echo e(auth()->user()->name); ?>

                    </button>
                    <div aria-labelledby="dropdownMenu4"
                         class="dropdown-menu dropdown-menu-right dropdown-menu dropdown-menu-right">
                        <button onclick="dark()" class="dropdown-item" type="button"><i
                                class="fas fa-moon fa-sm c-main mr-2"></i>الوضع المظلم
                        </button>
                        <a href="<?php echo e(route('admin.profile.index')); ?>" class="dropdown-item"><i
                                class="far fa-user fa-sm c-main mr-2"></i>الإعدادات</a>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                            <i class="fas fa-sign-out-alt c-main fa-sm mr-2"></i>
                            تسجيل الخروج
                            <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </a>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</header>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/salam/resources/views/admin/layout/navbar.blade.php ENDPATH**/ ?>