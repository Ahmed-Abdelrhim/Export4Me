
<!--========== SCROLL UP ==========-->
<a href="#" class="scrollup" id="scroll-up">
    <i class="bx bxs-chevrons-up"></i>
</a>

<!--=============== SCROLLREVEAL ===============-->
<script src="<?php echo e(asset('assets/js/scrollreveal.min.js')); ?>"></script>

<!--=============== SWIPER JS ===============-->
<script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>

<!--=============== MAIN JS ===============-->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>



<script src="<?php echo e(asset('js/vendor/modernizr.js')); ?>"></script>








<!-- Swiper JS -->
  <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

     <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper(".mySwiper", {
      effect: "coverflow",
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: "auto",
      coverflowEffect: {
        rotate: 0,
        stretch: 0,
        depth: 300,
        modifier: 1,
        slideShadows: false,
      },
      pagination: {
        el: ".swiper-pagination",
      },
    });
  </script>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/salam/resources/views/frontend/layouts/script.blade.php ENDPATH**/ ?>